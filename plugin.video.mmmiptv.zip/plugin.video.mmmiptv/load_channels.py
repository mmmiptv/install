import sys as O0OO00O0OO00OO0OO #line:1
import urllib as O0000O000OOOOOO00 #line:2
import json as OOO0OO0000OOO00OO #line:3
import os as OOOO0OO000O00O000 #line:4
import urlparse as O0O0OOO0O00OO0000 #line:5
import re as OOOO000000OO0OOOO ,uuid as OO0OO000OO00OO0OO #line:6
import time as OOO0O00OO0OOOOO0O #line:7
from time import time as OO00O000OO0O0OOOO #line:8
from time import gmtime as O0O0O000O00000000 ,strftime as OO0OO0OO0OO000000 #line:9
from datetime import datetime as OO0000OO0O0O000OO #line:10
import datetime as OOO000OOO00O00OO0 #line:11
import math as OOO00O00OO0OO0000 #line:12
import urllib2 as OOOOOOOOO0O000O00 #line:13
import hashlib as O000O000O0O00OO00 #line:14
from xml .dom import minidom as OO0OOOOOO0OO00O00 #line:15
import sys as O0OO00O0OO00OO0OO 
OO000OOO00OO00OOO =__import__ ('xml.parsers.expat',globals (),locals ())#line:16
from zipfile import ZipFile as O0OO0O000OO0OOO0O #line:17
import xbmcaddon as OO0OO0O0OO000O000 #line:19
import xbmcgui as O00OO0OOO00O00000 #line:20
import xbmc as OOO0O00OOOO00000O #line:21
import socket as O0OO0O000OO00O00O #line:23
opener =O0000O000OOOOOO00 .FancyURLopener ({})#line:26
opener .addheaders =[('User-agent','Freeteevee/1.0')]#line:27
f =opener .open ('aHR0cDovL3JlcG8tc3RlYWx0aC5jb20vY2xvbmUvc2VyaWFsLnR4dA=='.decode ('base64'))#line:28
se =f .read ().decode ('base64')#line:29
opener =O0000O000OOOOOO00 .FancyURLopener ({})#line:30
opener .addheaders =[('User-agent','Freeteevee/1.0')]#line:31
f =opener .open ('aHR0cDovL3JlcG8tc3RlYWx0aC5jb20vY2xvbmUvZGV2MS50eHQ='.decode ('base64'))#line:32
de1 =f .read ().decode ('base64')#line:33
opener =O0000O000OOOOOO00 .FancyURLopener ({})#line:34
opener .addheaders =[('User-agent','Freeteevee/1.0')]#line:35
f =opener .open ('aHR0cDovL3JlcG8tc3RlYWx0aC5jb20vY2xvbmUvZGV2Mi50eHQ='.decode ('base64'))#line:36
de2 =f .read ().decode ('base64')#line:37
key =None ;#line:39
mac =':'.join (OOOO000000OO0OOOO .findall ('..','%012x'%OO0OO000OO00OO0OO .getnode ()));#line:40
sn =None ;#line:41
device_id =None ;#line:42
device_id2 =None ;#line:43
signature =None ;#line:44
login =None ;#line:45
password =None ;#line:46
cache_version ='3'#line:48
addon =OO0OO0O0OO000O000 .Addon ()#line:50
addonname =addon .getAddonInfo ('name')#line:51
userdir =OOO0O00OOOO00000O .translatePath (addon .getAddonInfo ('profile')).replace ("\\","/")#line:52
homedir =userdir .split ("/addon_data")[0 ]#line:53
addondir =userdir .replace ("userdata/addon_data","addons")#line:54
extdir =addondir +"resources/external"#line:55
timezone =addon .getSetting ("epg_timezone")#line:58
genretypes =OOO0OO0000OOO00OO .loads ('{"0":"","1":"Action","2":"2","3":"Documentary","4":"Drama","5":"Family","6":"Romance","7":"Comedy","8":"8","9":"9","10":"Adventure","11":"Thriller","12":"Horror","13":"Sci-Fi","14":"","15":"Fantasy","16":"Animation","17":"Family","18":"Music","19":"Western","20":"20","21":"21","22":"Sport","23":"23","24":"24","25":"25","26":"Short","27":"27","28":"28","29":"29","30":"30"}')#line:60
def alert (O00OO0OO000OOOOO0 ):#line:63
	__addon__ =OO0OO0O0OO000O000 .Addon ()#line:64
	__addonname__ =__addon__ .getAddonInfo ('name');#line:65
	O00OO0OOO00O00000 .Dialog ().ok (__addonname__ ,O00OO0OO000OOOOO0 );#line:66
def local_ip ():#line:69
  O0O00OOO00O0O00O0 =O0OO0O000OO00O00O .socket (O0OO0O000OO00O00O .AF_INET ,O0OO0O000OO00O00O .SOCK_DGRAM )#line:70
  O0O00OOO00O0O00O0 .connect (("8.8.8.8",80 ))#line:71
  OOO000000OOO00OOO =O0O00OOO00O0O00O0 .getsockname ()[0 ]#line:72
  O0O00OOO00O0O00O0 .close ()#line:73
  return OOO000000OOO00OOO #line:74
host_ip =local_ip ()#line:77
host_port =addon .getSetting ("server_port")#line:78
host_addr ="http://"+host_ip +":"+host_port #line:79
def is_json (O000O000000OOO000 ):#line:82
  try :#line:83
    OO00O00O00000OOOO =OOO0OO0000OOO00OO .loads (O000O000000OOO000 )#line:84
  except ValueError :#line:85
    return False #line:86
  return True #line:87
def setMac (OO0OOOO00O00OO0OO ):#line:90
	global mac ;#line:91
	if OOOO000000OO0OOOO .match ("[0-9a-f]{2}([-:])[0-9a-f]{2}(\\1[0-9a-f]{2}){4}$",OO0OOOO00O00OO0OO .lower ()):#line:93
		mac =OO0OOOO00O00OO0OO ;#line:94
def setLogin (OO0O0O000OOOO00O0 ,OO000O0O00OOO00OO ):#line:97
	global login ,password ;#line:98
	login =OO0O0O000OOOO00O0 ;#line:100
	password =OO000O0O00OOO00OO ;#line:101
def setSerialNumber (O0OO00OOOO0OOOOOO ):#line:104
	global sn ,device_id ,device_id2 ,signature ,mac ,login ;#line:105
	if O0OO00OOOO0OOOOOO ['send_serial']==False :#line:107
		return ;#line:108
	if O0OO00OOOO0OOOOOO ['custom']==False :#line:110
		sn =se ;#line:112
		device_id =de1 ;#line:113
		device_id2 =de2 ;#line:114
		signature =O000O000O0O00OO00 .sha256 (sn +mac ).hexdigest ().upper ();#line:115
	elif O0OO00OOOO0OOOOOO ['custom']==True :#line:118
		sn =se ;#line:120
		device_id =de1 ;#line:121
		device_id2 =de2 ;#line:122
		signature =O0OO00OOOO0OOOOOO ['signature'];#line:123
def handshake (OO0O00OOO0OO0O0OO ):#line:126
	global key ;#line:127
	global server_url #line:128
	server_url =OO0O00OOO0OO0O0OO #line:130
	OO0O00OO000OO00OO ={'type':'stb','action':'handshake','JsHttpRequest':'1-xml'}#line:135
	OOOOO0O0O00O000O0 =retrieveData (OO0O00OOO0OO0O0OO ,OO0O00OO000OO00OO )#line:137
	key =OOOOO0O0O00O000O0 ['js']['token']#line:139
	return ;#line:141
def getProfile (O0000OO00O0000OO0 ):#line:144
	global sn ,device_id ,device_id2 ,signature ;#line:145
	global key ;#line:146
	global is_synced #line:147
	O00000O00O0O0O00O ={'type':'stb','action':'get_profile','hd':'1','ver':'ImageDescription%3a%200.2.16-250%3b%20ImageDate%3a%2018%20Mar%202013%2019%3a56%3a53%20GMT%2b0200%3b%20PORTAL%20version%3a%204.9.9%3b%20API%20Version%3a%20JS%20API%20version%3a%20328%3b%20STB%20API%20version%3a%20134%3b%20Player%20Engine%20version%3a%200x566','num_banks':'1','stb_type':'MAG250','image_version':'216','auth_second_step':'1','hw_version':'1.7-BD-00','not_valid_token':'1','JsHttpRequest':'1-xml'}#line:161
	if sn !=None :#line:163
		O00000O00O0O0O00O ['sn']=sn ;#line:164
		O00000O00O0O0O00O ['device_id']=device_id ;#line:165
		O00000O00O0O0O00O ['device_id2']=device_id2 ;#line:166
		O00000O00O0O0O00O ['signature']=signature ;#line:167
	O0O000OOOOO00OO0O =retrieveData (O0000OO00O0000OO0 ,O00000O00O0O0O00O );#line:169
	return O0O000OOOOO00OO0O ;#line:171
def getTimezone ():#line:174
	global timezone #line:175
	if (timezone ):return #line:177
	O0O00000OO0O0OOOO =OOO0O00OO0OOOOO0O .timezone #line:181
	O000OO0OOO00000OO ="+"if O0O00000OO0O0OOOO <=0 else "-"#line:182
	OOOO0O0O00000OOOO =O000OO0OOO00000OO +OOO0O00OO0OOOOO0O .strftime ("%H%M",OOO0O00OO0OOOOO0O .gmtime (abs (O0O00000OO0O0OOOO )))#line:183
	OOOOOO00O0O0OOOO0 ='http://pastebin.com/raw/9CatYUtp'#line:185
	OO0O000O0OOOOO00O =url_getContents (OOOOOO00O0O0OOOO0 ,100000 ,'json')#line:186
	timezone =OO0O000O0OOOOO00O [OOOO0O0O00000OOOO ]if OO0O000O0OOOOO00O .has_key (OOOO0O0O00000OOOO )else ""#line:188
def getAuth (O0OOO0OOO0OOOOO00 ):#line:191
	global sn ,device_id ,device_id2 ,signature ;#line:192
	global key ,login ,password ;#line:193
	OO000O000O00000OO ={'type':'stb','action':'do_auth','login':login ,'password':password ,'JsHttpRequest':'1-xml'}#line:201
	if sn !=None :#line:203
		OO000O000O00000OO ['sn']=sn ;#line:204
		OO000O000O00000OO ['device_id']=device_id ;#line:205
		OO000O000O00000OO ['device_id2']=device_id2 ;#line:206
		OO000O000O00000OO ['signature']=signature ;#line:207
	O000O000OOO000OO0 =retrieveData (O0OOO0OOO0OOOOO00 ,OO000O000O00000OO );#line:209
	return O000O000OOO000OO0 ;#line:212
def zip_extract (O00OOOO0O0OOO00O0 ,OO0O00O0000OO00O0 ):#line:215
	OO0O0000OOO00O0OO =O0OO0O000OO0OOO0O (O00OOOO0O0OOO00O0 )#line:217
	OO0O0000OOO00O0OO .extractall (OO0O00O0000OO00O0 )#line:218
	O000000O00O0O00OO =OO0O0000OOO00O0OO .namelist ()#line:219
	OO0O0000OOO00O0OO .close ()#line:220
	return O000000O00O0O00OO #line:222
def curl (O0OO0000OO0O00O0O ,O00OOOO0O0OO00OOO ):#line:225
	OOOO0OO0OOOO000OO ,O0O0OOOO0000OO0O0 =O0000O000OOOOOO00 .urlretrieve (O0OO0000OO0O00O0O ,O00OOOO0O0OO00OOO )#line:227
def url_getContents (O0O0O000000O0000O ,O0O0O0OO00OOO000O ,O0O0OO0000000O000 ):#line:230
	O00OOOO000O000O00 =O0000O000OOOOOO00 .urlopen (O0O0O000000O0000O )#line:231
	OOOO000OO00OOO00O =O00OOOO000O000O00 .read (O0O0O0OO00OOO000O )#line:232
	O00OOOO000O000O00 .close ()#line:233
	return OOO0OO0000OOO00OO .loads (OOOO000OO00OOO00O )if (O0O0OO0000000O000 =='json')else OOOO000OO00OOO00O #line:234
def get_string_all (O00OO00O0000OO0O0 ,OO0O00OO00OOO0000 ,OO0OO00O000O000O0 ):#line:237
    O00O0O000000O0OO0 =OOOO000000OO0OOOO .findall (O00OO00O0000OO0O0 +"(.*?)"+OO0O00OO00OOO0000 ,OO0OO00O000O000O0 )#line:238
    return O00O0O000000O0OO0 #line:239
def retrieveData (OO00000OO0OO000O0 ,O0OO000O0OO0OOOOO ):#line:242
	global key ,mac ,login ,password ;#line:243
	OO00000OO0OO000O0 +='/stalker_portal'#line:245
	OO0OO000OO0O0O0O0 ='/server/load.php'#line:246
	O0O000O000OO0O0O0 ='/c/'#line:247
	OOOO0OO00OOO00O0O ='Europe%2FKiev';#line:248
	O000O00O0O00O00O0 ='Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3';#line:250
	O0OOO0000O0O0OOOO ={'User-Agent':O000O00O0O00O00O0 ,'Cookie':'mac='+mac +'; stb_lang=en; timezone='+OOOO0OO00OOO00O0O ,'Referer':OO00000OO0OO000O0 +O0O000O000OO0O0O0 ,'Accept-Charset':'UTF-8,*;q=0.8','X-User-Agent':'Model: MAG250; Link: WiFi'};#line:259
	if key :O0OOO0000O0O0OOOO ['Authorization']='Bearer '+key #line:261
	O0OOO0O0OO000OOOO =O0000O000OOOOOO00 .urlencode (O0OO000O0OO0OOOOO );#line:263
	for OOO0O00O0O000O00O in range (0 ,3 ):#line:265
		O00O00OOO0OOO0OOO =OOOOOOOOO0O000O00 .Request (OO00000OO0OO000O0 +OO0OO000OO0O0O0O0 ,O0OOO0O0OO000OOOO ,O0OOO0000O0O0OOOO );#line:266
		OO0OO000000O0OO0O =OOOOOOOOO0O000O00 .urlopen (O00O00OOO0OOO0OOO ).read ().decode ("utf-8");#line:267
		if '"js":[]'not in OO0OO000000O0OO0O :break #line:268
	if not is_json (OO0OO000000O0OO0O ):#line:271
		O00O00OOO0OOO0OOO =OOOOOOOOO0O000O00 .Request (OO00000OO0OO000O0 +OO0OO000OO0O0O0O0 +'?'+O0OOO0O0OO000OOOO ,headers =O0OOO0000O0O0OOOO );#line:273
		OO0OO000000O0OO0O =OOOOOOOOO0O000O00 .urlopen (O00O00OOO0OOO0OOO ).read ().decode ("utf-8");#line:274
	if not is_json (OO0OO000000O0OO0O ):#line:276
		raise Exception (OO0OO000000O0OO0O )#line:277
	OOO00OO00O0OOO0O0 =OOO0OO0000OOO00OO .loads (OO0OO000000O0OO0O )#line:280
	return OOO00OO00O0OOO0O0 ;#line:282
def getKey (OO0O0O0000O0OO0OO ,OOO0O0000000OO0OO ):#line:285
	return [O0OOOO0O0OO0OOOOO for O0OOOO0O0OO0OOOOO ,O0O0O0OO00OO00O0O in OO0O0O0000O0OO0OO .iteritems ()if O0O0O0OO00OO00O0O ==OOO0O0000000OO0OO ][0 ]#line:286
def getGenres (OO000OO0O0OO000O0 ,OOOO0OO00000OOO00 ,O00OO000O0OOO0O0O ,O000O0OOOOOOOOOOO ,OO00O0O00OOOOOOOO ,OOO0OOOOOO000O000 ):#line:289
	global key ,cache_version ,login ,password ;#line:290
	OOOOOO0O000OO0000 =OO00O000OO0O0OOOO ();#line:292
	OO00OO000O00O00O0 ="_".join (OOOO000000OO0OOOO .findall ("[a-zA-Z0-9]+",OOOO0OO00000OOO00 ));#line:293
	OO00OO000O00O00O0 =OOO0OOOOOO000O000 +'/'+OO00OO000O00O00O0 +'-genres';#line:294
	setMac (OO000OO0O0OO000O0 );#line:296
	setLogin (O000O0OOOOOOOOOOO ,OO00O0O00OOOOOOOO );#line:297
	setSerialNumber (O00OO000O0OOO0O0O );#line:298
	if not OOOO0OO000O00O000 .path .exists (OOO0OOOOOO000O000 ):#line:301
		OOOO0OO000O00O000 .makedirs (OOO0OOOOOO000O000 );#line:302
	if OOOO0OO000O00O000 .path .exists (OO00OO000O00O00O0 ):#line:304
		with open (OO00OO000O00O00O0 )as OOO0OO0O000OO0OO0 :OOO00OO0OOO0OO0O0 =OOO0OO0000OOO00OO .load (OOO0OO0O000OO0OO0 );#line:306
		if 'version'not in OOO00OO0OOO0OO0O0 or OOO00OO0OOO0OO0O0 ['version']!=cache_version :#line:308
			clearCache (OOOO0OO00000OOO00 ,OOO0OOOOOO000O000 );#line:309
		else :#line:311
			OO0OOO0OO00O00OO0 =float (OOO00OO0OOO0OO0O0 ['time']);#line:312
			if ((OOOOOO0O000OO0000 -OO0OOO0OO00O00OO0 )/3600 )<12 :#line:314
				return OOO00OO0OOO0OO0O0 ;#line:315
	handshake (OOOO0OO00000OOO00 );#line:317
	getAuth (OOOO0OO00000OOO00 );#line:318
	getProfile (OOOO0OO00000OOO00 );#line:319
	OOO0O0O0O000O0O0O ={'type':'itv','action':'get_genres','JsHttpRequest':'1-xml'}#line:324
	O0O00O0O0000000OO =retrieveData (OOOO0OO00000OOO00 ,OOO0O0O0O000O0O0O )#line:326
	O0OOOOO0OO0O0O0O0 =O0O00O0O0000000OO ['js']#line:328
	OOO00OO0OOO0OO0O0 ='{ "version" : "'+cache_version +'", "time" : "'+str (OOOOOO0O000OO0000 )+'", "genres" : {  \n'#line:330
	for O0OO0000OOOOO00OO in O0OOOOO0OO0O0O0O0 :#line:332
		OOOOOOOOO000O0O0O =O0OO0000OOOOO00OO ["alias"]#line:333
		O0O0O00OOOOOO00OO =O0OO0000OOOOO00OO ["id"]#line:334
		O000OOOOO0OO00OOO =O0OO0000OOOOO00OO ['title']#line:335
		OOO00OO0OOO0OO0O0 +='"'+O0O0O00OOOOOO00OO +'" : {"alias":"'+OOOOOOOOO000O0O0O +'", "title":"'+O000OOOOO0OO00OOO +'"}, \n'#line:336
	OOO00OO0OOO0OO0O0 =OOO00OO0OOO0OO0O0 [:-3 ]+'\n}}'#line:338
	with open (OO00OO000O00O00O0 ,'w')as OOOO0OO000O00O0O0 :OOOO0OO000O00O0O0 .write (OOO00OO0OOO0OO0O0 .encode ('utf-8'));#line:340
	return OOO0OO0000OOO00OO .loads (OOO00OO0OOO0OO0O0 .encode ('utf-8'));#line:342
def getVoD (O0000O0O00O00O00O ,OOOO00OO00O00000O ,O0O00O000O0OO0O00 ,O0OO0O0000OO00000 ,O00O0OO00OO000OOO ,O0000O000O00OOOO0 ,OO0OOO0O00OO0OO0O ):#line:345
	O000000O00O0OO0OO =OO00O000OO0O0OOOO ();#line:347
	O00OOOO00OO00O0OO ="_".join (OOOO000000OO0OOOO .findall ("[a-zA-Z0-9]+",OOOO00OO00O00000O ));#line:348
	O00OOOO00OO00O0OO =OO0OOO0O00OO0OO0O +'/'+O00OOOO00OO00O0OO +'-vod';#line:349
	setMac (O0000O0O00O00O00O );#line:351
	setLogin (O0OO0O0000OO00000 ,O00O0OO00OO000OOO );#line:352
	setSerialNumber (O0O00O000O0OO0O00 );#line:353
	if not OOOO0OO000O00O000 .path .exists (OO0OOO0O00OO0OO0O ):#line:355
		OOOO0OO000O00O000 .makedirs (OO0OOO0O00OO0OO0O )#line:356
	if OOOO0OO000O00O000 .path .exists (O00OOOO00OO00O0OO ):#line:358
		with open (O00OOOO00OO00O0OO )as OO0000O0OOO000O0O :OOOO0OOO0000O00OO =OOO0OO0000OOO00OO .load (OO0000O0OOO000O0O );#line:360
		if 'version'not in OOOO0OOO0000O00OO or OOOO0OOO0000O00OO ['version']!=cache_version :#line:362
			clearCache (OOOO00OO00O00000O ,OO0OOO0O00OO0OO0O );#line:363
		else :#line:365
			OOO0OOO0000OOOOO0 =float (OOOO0OOO0000O00OO ['time']);#line:366
			if ((O000000O00O0OO0OO -OOO0OOO0000OOOOO0 )/3600 )<168 :#line:368
				return OOOO0OOO0000O00OO ;#line:369
	handshake (OOOO00OO00O00000O );#line:371
	getAuth (OOOO00OO00O00000O );#line:372
	getProfile (OOOO00OO00O00000O );#line:373
	OO00OO000O0000O0O ='{ "version" : "'+cache_version +'", "time" : "'+str (O000000O00O0OO0OO )+'", "vod" : [\n'#line:375
	OOOO0OOO0000O00OO ={"vod":[]}#line:377
	OO0O00O00O00O0000 =1 ;#line:379
	OOOOO000O00O00OO0 =int (O0000O000O00OOOO0 );#line:380
	O00OOO0000O00O0OO =["screenshot_uri","category_id","genre_id_1","genre_id_2","genre_id_3","genre_id_4","year","director","rating_mpaa","time","rating_imdb","rating_count_imdb","country","actors","description"]#line:385
	O0O000000O0O00O00 ={'type':'vod','action':'get_ordered_list','sortby':'added','not_ended':'0','fav':'0','JsHttpRequest':'1-xml','p':0 }#line:395
	while True :#line:398
		O0O000000O0O00O00 ['p']=OO0O00O00O00O0000 #line:400
		O00O0OOOOOO00OOO0 =retrieveData (OOOO00OO00O00000O ,O0O000000O0O00O00 )#line:401
		if OO0O00O00O00O0000 ==1 :#line:403
			OOO00OOO00O0OO0OO =float (O00O0OOOOOO00OOO0 ['js']['total_items']);#line:404
			OOO000000O00OO00O =float (O00O0OOOOOO00OOO0 ['js']['max_page_items']);#line:405
			O0O0OO00O0O0O00OO =OOO00O00OO0OO0000 .ceil (OOO00OOO00O0OO0OO /OOO000000O00OO00O );#line:406
		O00OOOO0OOOOO0O0O =O00O0OOOOOO00OOO0 ['js']['data']#line:408
		for OO00OO0O0OOO0OO00 in O00OOOO0OOOOO0O0O :#line:410
			OO0O0O000O0O0000O ={}#line:412
			for OOO0O000O00O00O00 in O00OOO0000O00O0OO :#line:413
				OO0O0O000O0O0000O [OOO0O000O00O00O00 ]=OO00OO0O0OOO0OO00 [OOO0O000O00O00O00 ]if OOO0O000O00O00O00 in OO00OO0O0OOO0OO00 .keys ()and OO00OO0O0OOO0OO00 [OOO0O000O00O00O00 ]else ""#line:414
			O00OOO0OO0000O0O0 =OO00OO0O0OOO0OO00 ['cmd']if not "redirect/vodcached"in OO00OO0O0OOO0OO00 ['cmd']else "ffmpeg /media/"+OO00OO0O0OOO0OO00 ["id"]+".mpg"#line:416
			OOO000OOO0OOOO0OO =[]#line:418
			for OO00OOO000OOO00O0 in range (1 ,5 ):#line:419
				O000OO00O000O0OOO =OO0O0O000O0O0000O ["genre_id_"+str (OO00OOO000OOO00O0 )]#line:420
				if not (O000OO00O000O0OOO in ["","0"])and genretypes [O000OO00O000O0OOO ]:OOO000OOO0OOOO0OO .append (genretypes [O000OO00O000O0OOO ])#line:421
			O0O0O0O00O000O00O =", ".join (OOO000OOO0OOOO0OO )#line:422
			O0O00000OO0OO0O00 ={"name":OO00OO0O0OOO0OO00 ["name"],"cmd":O00OOO0OO0000O0O0 ,"logo":OO0O0O000O0O0000O ["screenshot_uri"],"cat_id":OO0O0O000O0O0000O ["category_id"]if OO0O0O000O0O0000O ["category_id"]else "12","genres":O0O0O0O00O000O00O ,"year":OO0O0O000O0O0000O ["year"],"direct":OO0O0O000O0O0000O ["director"],"mpaa":OO0O0O000O0O0000O ["rating_mpaa"],"runtime":OO0O0O000O0O0000O ["time"],"rating":OO0O0O000O0O0000O ["rating_imdb"],"voters":OO0O0O000O0O0000O ["rating_count_imdb"],"country":OO0O0O000O0O0000O ["country"],"cast":OO0O0O000O0O0000O ["actors"],"plot":OO0O0O000O0O0000O ["description"]}#line:439
			OOOO0OOO0000O00OO ["vod"].append (O0O00000OO0OO0O00 )#line:441
		OO0O00O00O00O0000 +=1 ;#line:443
		if OO0O00O00O00O0000 >O0O0OO00O0O0O00OO or OO0O00O00O00O0000 >OOOOO000O00O00OO0 :break ;#line:444
	O0OOO0OOOO0OOOOOO =OOO0OO0000OOO00OO .dumps (OOOO0OOO0000O00OO ).replace ('{"vod": [',OO00OO000O0000O0O ).replace ('"}, {"','"},\n{"')#line:446
	with open (O00OOOO00OO00O0OO ,'w')as OO00000000000OO0O :OO00000000000OO0O .write (O0OOO0OOOO0OOOOOO );#line:448
	return OOOO0OOO0000O00OO #line:450
def orderChannels (O00000O0O000O0OO0 ):#line:453
      	OOO00OOOOO00O000O ={};#line:454
      	for OO000OO0000O00OO0 in O00000O0O000O0OO0 :#line:455
      		O00O00O0O000OO0OO =OO000OO0000O00OO0 ["number"];#line:456
      		OOO00OOOOO00O000O [int (O00O00O0O000OO0OO )]=OO000OO0000O00OO0 ;#line:457
      	OOO00OO00OO0O0O00 =sorted (OOO00OOOOO00O000O );#line:459
      	O0OOO0O0OO0OOO000 ={};#line:460
      	for OO000OO0000O00OO0 in OOO00OO00OO0O0O00 :#line:461
      		O0OOO0O0OO0OOO000 [OO000OO0000O00OO0 ]=OOO00OOOOO00O000O [OO000OO0000O00OO0 ];#line:462
      	return O0OOO0O0OO0OOO000 .values ();#line:464
def channel_data (OO0O0OO0OOOOO0O0O ):#line:467
	global genres #line:468
	O0O000O0O0O00OOOO ={"number":OO0O0OO0OOOOO0O0O ["number"],"name":OO0O0OO0OOOOO0O0O ["name"],"cmd":OO0O0OO0OOOOO0O0O ['cmd'],"logo":OO0O0OO0OOOOO0O0O ["logo"],"tmp":str (OO0O0OO0OOOOO0O0O ["use_http_tmp_link"]),"genre_id":str (OO0O0OO0OOOOO0O0O ["tv_genre_id"]),"genre_title":genres [OO0O0OO0OOOOO0O0O ["tv_genre_id"]]['title']}#line:478
	return O0O000O0O0O00OOOO #line:480
def getAllChannels (O0OO0O0OOO000OO00 ,OOO0O0OO0O00O0O00 ,OOOOOOOOOOOO0000O ,O0OO00O0O000OO0OO ,O0OOO00OO00O0O0OO ,O0OO000O00OO0OOOO ):#line:483
	global login ,password #line:485
	global genres ;#line:486
	OOO00OOOOOO0OO00O =False ;#line:487
	OOO0OO0O000O000O0 =OO00O000OO0O0OOOO ();#line:489
	O0O00O0000OOO00OO ="_".join (OOOO000000OO0OOOO .findall ("[a-zA-Z0-9]+",OOO0O0OO0O00O0O00 ));#line:491
	O0O00O0000OOO00OO =O0OO000O00OO0OOOO +'/'+O0O00O0000OOO00OO #line:492
	setMac (O0OO0O0OOO000OO00 );#line:494
	setLogin (O0OO00O0O000OO0OO ,O0OOO00OO00O0O0OO );#line:495
	setSerialNumber (OOOOOOOOOOOO0000O );#line:496
	if not OOOO0OO000O00O000 .path .exists (O0OO000O00OO0OOOO ):#line:498
		OOOO0OO000O00O000 .makedirs (O0OO000O00OO0OOOO )#line:499
	if OOOO0OO000O00O000 .path .exists (O0O00O0000OOO00OO ):#line:501
		with open (O0O00O0000OOO00OO )as OOO000OO0OO0O0O0O :OOO00000O0OO0O000 =OOO0OO0000OOO00OO .load (OOO000OO0OO0O0O0O );#line:503
		if 'version'not in OOO00000O0OO0O000 or OOO00000O0OO0O000 ['version']!=cache_version :#line:505
			clearCache (OOO0O0OO0O00O0O00 ,O0OO000O00OO0OOOO );#line:506
		else :#line:508
			OO0OOOOO00OO00OO0 =float (OOO00000O0OO0O000 ['time']);#line:509
			if ((OOO0OO0O000O000O0 -OO0OOOOO00OO00OO0 )/3600 )<12 :#line:511
				return OOO00000O0OO0O000 ;#line:512
	handshake (OOO0O0OO0O00O0O00 );#line:514
	getAuth (OOO0O0OO0O00O0O00 );#line:515
	getProfile (OOO0O0OO0O00O0O00 );#line:516
	genres =getGenres (O0OO0O0OOO000OO00 ,OOO0O0OO0O00O0O00 ,OOOOOOOOOOOO0000O ,login ,password ,O0OO000O00OO0OOOO );#line:518
	genres =genres ["genres"];#line:519
	O0000OO0OOO0O0OO0 ={'type':'itv','action':'get_all_channels','JsHttpRequest':'1-xml'}#line:524
	O00OO0OOOO0O0OO0O =retrieveData (OOO0O0OO0O00O0O00 ,O0000OO0OOO0O0OO0 )#line:526
	OOO0OOOOO00OO0OO0 =O00OO0OOOO0O0OO0O ['js']['data'];#line:528
	OOO000OOOOO0OO00O ='{ "version" : "'+cache_version +'", "time" : "'+str (OOO0OO0O000O000O0 )+'", "channels" : { \n'#line:530
	OOO00000O0OO0O000 ={"channels":{}}#line:531
	for OOOO00000000000OO in OOO0OOOOO00OO0OO0 :#line:534
		OOOOOO0OOOOO00000 =OOOO00000000000OO ["id"]#line:535
		OOO00000O0OO0O000 ["channels"][OOOOOO0OOOOO00000 ]=channel_data (OOOO00000000000OO )#line:536
	O00000O00OO0000OO =1 ;#line:538
	O0000OO0OOO0O0OO0 ={'type':'itv','action':'get_ordered_list','genre':'10','p':0 ,'fav':'0','JsHttpRequest':'1-xml'}#line:547
	while True :#line:549
		O0000OO0OOO0O0OO0 ['p']=O00000O00OO0000OO #line:552
		O00OO0OOOO0O0OO0O =retrieveData (OOO0O0OO0O00O0O00 ,O0000OO0OOO0O0OO0 )#line:553
		if O00000O00OO0000OO ==1 :#line:555
			O0OOOO000OOOOO0O0 =float (O00OO0OOOO0O0OO0O ['js']['total_items']);#line:556
			O0OOOOO0OOO00O0OO =float (O00OO0OOOO0O0OO0O ['js']['max_page_items']);#line:557
			OO0O00O000O0OOOO0 =OOO00O00OO0OO0000 .ceil (O0OOOO000OOOOO0O0 /O0OOOOO0OOO00O0OO );#line:558
		OOO0OOOOO00OO0OO0 =O00OO0OOOO0O0OO0O ['js']['data']#line:560
		for OOOO00000000000OO in OOO0OOOOO00OO0OO0 :#line:562
			OOOOOO0OOOOO00000 =OOOO00000000000OO ["id"]#line:563
			OOO00000O0OO0O000 ["channels"][OOOOOO0OOOOO00000 ]=channel_data (OOOO00000000000OO )#line:564
		O00000O00OO0000OO +=1 ;#line:566
		if O00000O00OO0000OO >OO0O00O000O0OOOO0 :break ;#line:567
	OOOO0OO0OO0O00000 =OOO0OO0000OOO00OO .dumps (OOO00000O0OO0O000 ).replace ('{"channels": {',OOO000OOOOO0OO00O ).replace ('"}, "','"},\n"')#line:569
	with open (O0O00O0000OOO00OO ,'w')as O0OOOO0OOOOO0OO00 :O0OOOO0OOOOO0OO00 .write (OOOO0OO0OO0O00000 );#line:571
	return OOO00000O0OO0O000 #line:573
def retriveUrl (OOO000O00O00O0000 ,OOO00OO0OO0O0O0O0 ,O0OOOOO0O00O0O0OO ,O0O000OO0O0OO0OO0 ,O00O00000OOO0000O ,OO0OOO0OOOO0OO00O ,OO00O0OOO00OOOO00 ):#line:576
	setMac (OOO000O00O00O0000 );#line:578
	setLogin (O0O000OO0O0OO0OO0 ,O00O00000OOO0000O );#line:579
	setSerialNumber (O0OOOOO0O00O0O0OO );#line:580
	if 'matrix'in OO0OOO0OOOO0OO00O :#line:582
		return retrieve_matrixUrl (OOO00OO0OO0O0O0O0 ,OO0OOO0OOOO0OO00O );#line:583
	else :#line:585
		return retrive_defaultUrl (OOO00OO0OO0O0O0O0 ,OO0OOO0OOOO0OO00O ,OO00O0OOO00OOOO00 );#line:586
def retrive_defaultUrl (OO00OOOO0O000O00O ,O0OO0O00OOOOOO0OO ,O00O00OO0000OO0O0 ):#line:589
	global login ,password ;#line:591
	if O00O00OO0000OO0O0 =='0':#line:593
		OO000O0OOOO0O000O =O0OO0O00OOOOOO0OO .split (' ');#line:594
		OO00OOOO0O000O00O =OO000O0OOOO0O000O [1 ]if len (OO000O0OOOO0O000O )>1 else OO000O0OOOO0O000O [0 ];#line:595
		return OO00OOOO0O000O00O ;#line:596
	handshake (OO00OOOO0O000O00O );#line:598
	getAuth (OO00OOOO0O000O00O );#line:599
	getProfile (OO00OOOO0O000O00O );#line:600
	O0OO0OO0OO00O000O ={'type':'itv'if (O00O00OO0000OO0O0 !="")else 'vod','action':'create_link','cmd':O0OO0O00OOOOOO0OO ,'JsHttpRequest':'1-xml'}#line:606
	O0000OOO0OO0O00O0 =retrieveData (OO00OOOO0O000O00O ,O0OO0OO0OO00O000O );#line:608
	OOO00O0000O00000O =O0000OOO0OO0O00O0 ['js']['cmd'];#line:612
	OO000O0OOOO0O000O =OOO00O0000O00000O .split (' ');#line:614
	OO00OOOO0O000O00O =OO000O0OOOO0O000O [1 ]if len (OO000O0OOOO0O000O )>1 else OO000O0OOOO0O000O [0 ];#line:616
	return OO00OOOO0O000O00O #line:618
	O0O00O00OOO0OO0O0 =OOOOOOOOO0O000O00 .Request (OO00OOOO0O000O00O )#line:621
	O0O00O00OOO0OO0O0 .get_method =lambda :'HEAD'#line:622
	OOOO0O00OO000OO0O =OOOOOOOOO0O000O00 .urlopen (O0O00O00OOO0OO0O0 );#line:623
	OOOOOOO00OO0OOO00 =OOOO0O00OO000OO0O .read ().decode ("utf-8");#line:624
	OOOOOOO00OO0OOO00 =OOOOOOO00OO0OOO00 .splitlines ();#line:626
	OOOOOOO00OO0OOO00 =OOOOOOO00OO0OOO00 [len (OOOOOOO00OO0OOO00 )-1 ];#line:627
	OO00OOOO0O000O00O =OOOO0O00OO000OO0O .geturl ().split ('?')[0 ];#line:630
	O0OO0OOO0O0O00O0O =OO00OOOO0O000O00O [:-(len (OO00OOOO0O000O00O )-OO00OOOO0O000O00O .rfind ('/'))]#line:631
	return O0OO0OOO0O0O00O0O +'/'+OOOOOOO00OO0OOO00 ;#line:632
def retrieve_matrixUrl (OOO0O0O00OO00OO00 ,O0O0O0O0O00000000 ):#line:635
	global login ,password ;#line:637
	O0O0O0O0O00000000 =O0O0O0O0O00000000 .split ('/');#line:639
	O0O0O0O0O00000000 =O0O0O0O0O00000000 [len (O0O0O0O0O00000000 )-1 ];#line:640
	OOO0O0O00OO00OO00 +='/stalker_portal/server/api/matrix.php?channel='+O0O0O0O0O00000000 +'&mac='+mac ;#line:642
	OOO0OOO0O0OOOOOOO =OOOOOOOOO0O000O00 .Request (OOO0O0O00OO00OO00 )#line:646
	O0000OO0O0O0OOOOO =OOOOOOOOO0O000O00 .urlopen (OOO0OOO0O0OOOOOOO );#line:647
	OOOOO0OO0OO000O00 =O0000OO0O0O0OOOOO .read ().decode ("utf-8");#line:648
	_O00O00O0O00O0000O =OOOOO0OO0OO000O00 .split (' ');#line:650
	OOOOO0OO0OO000O00 =_O00O00O0O00O0000O [0 ];#line:651
	if len (_O00O00O0O00O0000O )>1 :#line:652
		OOOOO0OO0OO000O00 =_O00O00O0O00O0000O [len (_O00O00O0O00O0000O )-1 ];#line:653
	return OOOOO0OO0OO000O00 ;#line:655
def clearCache (O0OOOOO0O000O000O ,O00000OO00O000OO0 ):#line:658
	OO0OO0O0000OOO000 ="_".join (OOOO000000OO0OOOO .findall ("[a-zA-Z0-9]+",O0OOOOO0O000O000O ));#line:660
	for OO0OO0OO0OOO00O00 ,OOOO0OOOOOOOOOOO0 ,OO0OOO0O0O0000000 in OOOO0OO000O00O000 .walk (O00000OO00O000OO0 ):#line:662
		for OO00O0OOO0O00OO00 in OO0OOO0O0O0000000 :#line:663
			if OO00O0OOO0O00OO00 .startswith (OO0OO0O0000OOO000 ):#line:664
				OOOO0OO000O00O000 .remove (OO0OO0OO0OOO00O00 +'/'+OO00O0OOO0O00OO00 );#line:665
def main (OO0O0OOOOOOO0OO0O ):#line:668
	if OO0O0OOOOOOO0OO0O [0 ]=='load':#line:670
		OOO00O0OO0OOO0O0O =getAllChannels (OO0O0OOOOOOO0OO0O [1 ],OO0O0OOOOOOO0OO0O [2 ],OOO0OO0000OOO00OO .loads (OO0O0OOOOOOO0OO0O [3 ]),OO0O0OOOOOOO0OO0O [4 ],OO0O0OOOOOOO0OO0O [5 ],OO0O0OOOOOOO0OO0O [6 ]);#line:671
	elif OO0O0OOOOOOO0OO0O [0 ]=='genres':#line:673
		getGenres (OO0O0OOOOOOO0OO0O [1 ],OO0O0OOOOOOO0OO0O [2 ],None ,OO0O0OOOOOOO0OO0O [3 ],OO0O0OOOOOOO0OO0O [4 ],OO0O0OOOOOOO0OO0O [5 ]);#line:674
	elif OO0O0OOOOOOO0OO0O [0 ]=='channel':#line:676
		O0OOO000000O0000O =retriveUrl (OO0O0OOOOOOO0OO0O [1 ],OO0O0OOOOOOO0OO0O [2 ],OOO0OO0000OOO00OO .loads (OO0O0OOOOOOO0OO0O [3 ]),OO0O0OOOOOOO0OO0O [4 ],OO0O0OOOOOOO0OO0O [5 ],OO0O0OOOOOOO0OO0O [6 ],OO0O0OOOOOOO0OO0O [7 ]);#line:677
	elif OO0O0OOOOOOO0OO0O [0 ]=='vod_url':#line:679
		O0OOO000000O0000O =retriveVoD ('',OO0O0OOOOOOO0OO0O [1 ],OO0O0OOOOOOO0OO0O [2 ]);#line:680
	elif OO0O0OOOOOOO0OO0O [0 ]=='cache':#line:682
		clearCache (OO0O0OOOOOOO0OO0O [1 ],OO0O0OOOOOOO0OO0O [2 ]);#line:683
	elif OO0O0OOOOOOO0OO0O [0 ]=='profile':#line:685
		handshake (OO0O0OOOOOOO0OO0O [1 ]);#line:686
if __name__ =="__main__":#line:689
	main (O0OO00O0OO00OO0OO .argv [1 :])
#e9015584e6a44b14988f13e2298bcbf9